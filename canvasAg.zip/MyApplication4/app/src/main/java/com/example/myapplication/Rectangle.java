package com.example.myapplication;

import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;

public class Rectangle {
    RectF rect;
    Paint color;

    public Rectangle(RectF rect, Paint color) {
        this.rect = rect;
        this.color = color;
    }

    public RectF getRect() {
        return rect;
    }

    public void setRect(RectF rect) {
        this.rect = rect;
    }

    public Paint getColor() {
        return color;
    }

    public void setColor(Paint color) {
        this.color = color;
    }
}
