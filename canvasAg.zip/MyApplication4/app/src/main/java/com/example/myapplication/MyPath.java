package com.example.myapplication;

import android.graphics.Paint;

import java.nio.file.Path;

public class MyPath {

    android.graphics.Path path;
    Paint color;
    boolean filled;

    public MyPath(android.graphics.Path path, Paint color) {
        this.path = path;
        this.color = color;
    }

    public android.graphics.Path getPath() {
        return path;
    }

    public void setPath(android.graphics.Path path) {
        this.path = path;
    }

    public Paint getColor() {
        return color;
    }

    public void setColor(Paint color) {
        this.color = color;
    }

    public boolean isFilled() {
        return filled;
    }

    public void setFilled(boolean filled) {
        this.filled = filled;
    }

}
