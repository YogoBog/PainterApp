package com.example.myapplication;

import android.graphics.Paint;
import android.graphics.RectF;

public class Circle {

    float centerX;
    float centerY;
    float radius;
    Paint color;

    public Paint getDrawColor() {
        return color;
    }

    public void setDrawColor(Paint drawColor) {
        this.color = drawColor;
    }

    Circle(float centerX, float centerY, float radius, Paint color) {
        this.centerX = centerX;
        this.centerY = centerY;
        this.radius = radius;
        this.color = color;
    }

    public RectF getBoundRect() {
        float left = centerX - radius;
        float top = centerY - radius;
        float right = centerX + radius;
        float bottom = centerY + radius;

        return new RectF(left, top, right, bottom);
    }

}
