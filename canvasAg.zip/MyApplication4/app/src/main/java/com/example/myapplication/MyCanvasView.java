package com.example.myapplication;

import static android.graphics.drawable.GradientDrawable.RECTANGLE;
import static android.icu.lang.UCharacter.DecompositionType.CIRCLE;
import static com.example.myapplication.MainActivity.circActive;
import static com.example.myapplication.MainActivity.fillActive;
import static com.example.myapplication.MainActivity.pathActive;
import static com.example.myapplication.MainActivity.recActive;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.content.res.Resources;

import androidx.core.content.res.ResourcesCompat;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;

public class MyCanvasView extends View {

    private static class DrawingAction {
        enum ActionType {CIRCLE, RECTANGLE, PATH, FILL}

        ActionType type;
        Paint paint;
        Circle circle;
        Rectangle rectangle;
        MyPath path;
        boolean filled;

        DrawingAction(ActionType type, Paint paint, Circle circle, Rectangle rectangle, MyPath path, boolean filled) {
            this.type = type;
            this.paint = paint;
            this.circle = circle;
            this.rectangle = rectangle;
            this.path = path;
            this.filled = filled;
        }
    }

    private List<DrawingAction> undoneActions = new ArrayList<>();


    private List<DrawingAction> drawingActions = new ArrayList<>();

    private MyPath currPath;
    private Rectangle currentRec;
    private Circle currentCircle;
    private Paint mFramePaint;
    private Paint cPaint;
    private List<MyPath> paths = new ArrayList<>();
    private int mBackgroundColor;
    private Canvas mExtraCanvas;
    private Bitmap mExtraBitmap;
    private Rect mFrame;
    private float prevX, prevY;
    private float finalX, finalY;
    private List<Circle> circles = new ArrayList<>();
    private List<Rectangle> recs = new ArrayList<>();
    private int drawColor;
    private int cDrawColor;


    MyCanvasView(Context context) {
        this(context, null);
    }

    public MyCanvasView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);

        mBackgroundColor =
                ResourcesCompat.getColor(getResources(), R.color.teal_200, null);
        drawColor = ResourcesCompat.getColor(getResources(), R.color.black, null);
        int frameColor = ResourcesCompat.getColor(getResources(), R.color.colorAccent, null);

        mFramePaint = new Paint();
        mFramePaint.setColor(frameColor);
        mFramePaint.setStyle(Paint.Style.STROKE);
        mFramePaint.setStrokeWidth(14);

        cPaint = new Paint();
        cPaint.setColor(drawColor);
        cPaint.setAntiAlias(true);
        cPaint.setDither(true);
        cPaint.setStyle(Paint.Style.STROKE);
        cPaint.setStrokeJoin(Paint.Join.ROUND);
        cPaint.setStrokeCap(Paint.Cap.ROUND);
        cPaint.setStrokeWidth(12);

        cDrawColor = drawColor;

    }

    @Override
    protected void onSizeChanged(int width, int height,
                                 int oldWidth, int oldHeight) {
        super.onSizeChanged(width, height, oldWidth, oldHeight);
        mExtraBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        mExtraCanvas = new Canvas(mExtraBitmap);
        mExtraCanvas.drawColor(mBackgroundColor);

        int inset = 40;
        mFrame = new Rect(inset, inset, width - inset, height - inset);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvas.drawBitmap(mExtraBitmap, 0, 0, null);
        canvas.drawRect(mFrame, mFramePaint);

        if (pathActive) {
            for (MyPath myPath : paths) {
                canvas.drawPath(myPath.getPath(), myPath.getColor());
            }
            if (currPath != null) {
                canvas.drawPath(currPath.getPath(), currPath.getColor());
            }
        } else {
            for (MyPath myPath : paths) {
                canvas.drawPath(myPath.getPath(), myPath.getColor());
            }
        }

        if (circActive) {
            for (Circle circle : circles) {
                Path path_eclipse = new Path();
                path_eclipse.addCircle(circle.centerX, circle.centerY, circle.radius, Path.Direction.CCW);
                canvas.drawPath(path_eclipse, circle.getDrawColor());
            }

            if (currentCircle != null) {
                Path path_eclipse = new Path();
                path_eclipse.addCircle(currentCircle.centerX, currentCircle.centerY, currentCircle.radius, Path.Direction.CCW);
                canvas.drawPath(path_eclipse, currentCircle.getDrawColor());
            }
        } else {
            for (Circle circle : circles) {
                Path path_eclipse = new Path();
                path_eclipse.addCircle(circle.centerX, circle.centerY, circle.radius, Path.Direction.CCW);
                canvas.drawPath(path_eclipse, circle.getDrawColor());
            }
        }

        if (recActive) {
            for (Rectangle rect : recs) {
                canvas.drawRect(rect.getRect(), rect.getColor());
            }
            if (currentRec != null) {
                canvas.drawRect(currentRec.getRect(), currentRec.getColor());
            }
        } else {
            for (Rectangle rect : recs) {  //RectF
                canvas.drawRect(rect.getRect(), rect.getColor());
            }
        }

    }

    private static final float TOUCH_TOLERANCE = 4;

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                if (fillActive) {
                    fillShapes(x, y);
                } else {
                    touchStart(x, y);
                }
                break;
            case MotionEvent.ACTION_MOVE:
                if (!fillActive) {
                    touchMove(x, y);
                    invalidate();
                }
                break;
            case MotionEvent.ACTION_UP:
                if (!fillActive) {
                    touchUp();
                    invalidate();
                }
                break;
            default:
        }
        return true;
    }

    private void touchStart(float x, float y) {
        if (pathActive) {
            currPath = new MyPath(new Path(), new Paint(cPaint));
            currPath.getPath().moveTo(x, y);
            currPath.getColor().setColor(cDrawColor);
            drawingActions.add(new DrawingAction(DrawingAction.ActionType.PATH, currPath.getColor(), null, null, currPath, false));
        } else if (circActive) {
            currentCircle = new Circle(x, y, 0, new Paint(cPaint));
            currentCircle.color.setColor(cDrawColor);
            if (fillActive)
                currentCircle.color.setStyle(Paint.Style.FILL);
            drawingActions.add(new DrawingAction(DrawingAction.ActionType.CIRCLE, currentCircle.color, currentCircle, null, null, false));

        } else if (recActive) {
            currentRec = new Rectangle(new RectF(x, y, x, y), new Paint(cPaint));
            currentRec.color.setColor(cDrawColor);
            drawingActions.add(new DrawingAction(DrawingAction.ActionType.RECTANGLE, currentRec.color, null, currentRec, null, false));
        }


        prevX = x;
        prevY = y;
    }

    private void touchMove(float x, float y) {
        finalX = x;
        finalY = y;
        float dx = Math.abs(x - prevX);
        float dy = Math.abs(y - prevY);
        if (dx >= TOUCH_TOLERANCE || dy >= TOUCH_TOLERANCE) {

            if (currentCircle != null) {
                currentCircle.radius = (float) Math.sqrt(Math.pow(x - prevX, 2.0f) + Math.pow(y - prevY, 2.0f)) / 2.0f;
            } else if (currentRec != null) {
                currentRec.getRect().set(Math.min(prevX, x), Math.min(prevY, y), Math.max(prevX, x), Math.max(prevY, y));
            } else if (currPath != null) {
                currPath.getPath().quadTo(prevX, prevY, (x + prevX) / 2, (y + prevY) / 2);

                prevX = x;
                prevY = y;
            }
        }
    }

    private void touchUp() {
        if (currentCircle != null) {
            circles.add(currentCircle);
            currentCircle = null;
            cPaint.setColor(drawColor);
            undoneActions.clear();
        } else if (currentRec != null) {
            recs.add(currentRec);
            currentRec = null;
            undoneActions.clear();
        } else if (currPath != null) {
            paths.add(currPath);
            currPath = null;
            undoneActions.clear();
        }
    }


    public void reset() {
        circles.clear();
        recs.clear();
        paths.clear();
        drawingActions.clear();
        undoneActions.clear();
        currentCircle = null;
        currentRec = null;
        currPath = null;
        mExtraCanvas.drawColor(mBackgroundColor);
        invalidate();
    }

    public void setDrawColor(int color) {
        cDrawColor = color;

        if (currentCircle != null) {
            currentCircle.color.setColor(color);
        }

        if (currentRec != null) {
            currentRec.color.setColor(color);
        }

        if (currPath != null) {
            currPath.getColor().setColor(color);
        }


        cPaint.setColor(color);
        invalidate();
    }


    public void undo() {
        if (!drawingActions.isEmpty()) {
            DrawingAction lastAction = drawingActions.remove(drawingActions.size() - 1);

            if (lastAction.type == DrawingAction.ActionType.CIRCLE) {
                circles.remove(lastAction.circle);
                currentCircle = null;
            } else if (lastAction.type == DrawingAction.ActionType.RECTANGLE) {
                recs.remove(lastAction.rectangle);
                currentRec = null;
            } else if (lastAction.type == DrawingAction.ActionType.PATH) {
                paths.remove(paths.size() - 1);
                currPath = null;
            } else if (lastAction.type == DrawingAction.ActionType.FILL) {
                undoFill(lastAction);
            }

            undoneActions.add(lastAction);
            redrawCanvas();
        }
    }

    private void undoFill(DrawingAction fillAction) {
        if (fillAction.circle != null) {
            undoFloodFillCircle(fillAction.circle);

        } else if (fillAction.rectangle != null) {
            fillAction.rectangle.color.setStyle(Paint.Style.STROKE);
        } else if (fillAction.path != null) {
            fillAction.path.setFilled(false);
            fillAction.path.color.setStyle(Paint.Style.STROKE);
        }
    }

    private void redrawCanvas() {
        mExtraCanvas.drawColor(mBackgroundColor);
        for (DrawingAction action : drawingActions) {
            switch (action.type) {
                case CIRCLE:
                    mExtraCanvas.drawCircle(action.circle.centerX, action.circle.centerY, action.circle.radius, action.paint);
                    break;
                case RECTANGLE:
                    mExtraCanvas.drawRect(action.rectangle.getRect(), action.paint);
                    break;
                case PATH:
                    mExtraCanvas.drawPath(action.path.getPath(), action.paint);
                    break;
            }
        }
        invalidate();
    }

    private void fillShapes(float x, float y) {

        for (Circle circle : circles) {
            if (isPointInCircle(x, y, circle)) {
                floodFillCircle(circle, x, y);
                drawingActions.add(new DrawingAction(DrawingAction.ActionType.FILL, circle.color, circle, null, null, true));
                return;
            }
        }

        for (Rectangle rect : recs) {
            if (isPointInRect(x, y, rect.getRect())) {
                floodFillRec(rect, x, y);
                drawingActions.add(new DrawingAction(DrawingAction.ActionType.FILL, rect.color, null, rect, null, true));
                return;
            }
        }


        for (MyPath myPath : paths) {
            if (isPointInPath(x, y, myPath)) {
                scanlineFillPath(myPath, x, y);
                drawingActions.add(new DrawingAction(DrawingAction.ActionType.FILL, myPath.getColor(), null, null, myPath, true));
                return;
            }
        }
    }


    private boolean isPointInPath(float x, float y, MyPath myPath) {
        RectF bounds = new RectF();
        myPath.getPath().computeBounds(bounds, true);
        Region region = new Region();
        region.setPath(myPath.getPath(), new Region((int) bounds.left, (int) bounds.top, (int) bounds.right, (int) bounds.bottom));
        return region.contains((int) x, (int) y);
    }

    private boolean isPointInCircle(float x, float y, Circle circle) {
        float dx = x - circle.centerX;
        float dy = y - circle.centerY;
        return dx * dx + dy * dy <= circle.radius * circle.radius;
    }

    private boolean isPointInRect(float x, float y, RectF rect) {
        return rect.contains(x, y);
    }


    private void floodFillCircle(Circle circle, float x, float y) {
        int targetColor = mExtraBitmap.getPixel((int) x, (int) y);
        int fillColor = cDrawColor;

        if (targetColor != fillColor) {
            Queue<Point> queue = new LinkedList<>();
            queue.add(new Point((int) x, (int) y));

            Set<Point> filledPoints = new HashSet<>();

            while (!queue.isEmpty()) {
                Point point = queue.poll();
                int px = point.x;
                int py = point.y;

                if (px >= 0 && px < mExtraBitmap.getWidth() && py >= 0 && py < mExtraBitmap.getHeight()) {
                    if (isPointInCircle(px, py, circle) && mExtraBitmap.getPixel(px, py) == targetColor && !filledPoints.contains(point)) {
                        mExtraBitmap.setPixel(px, py, fillColor);
                        filledPoints.add(new Point(px, py));

                        if (isPointInCircle(px + 1, py, circle) && mExtraBitmap.getPixel(px + 1, py) == targetColor) {
                            queue.add(new Point(px + 1, py));
                        }
                        if (isPointInCircle(px - 1, py, circle) && mExtraBitmap.getPixel(px - 1, py) == targetColor) {
                            queue.add(new Point(px - 1, py));
                        }
                        if (isPointInCircle(px, py + 1, circle) && mExtraBitmap.getPixel(px, py + 1) == targetColor) {
                            queue.add(new Point(px, py + 1));
                        }
                        if (isPointInCircle(px, py - 1, circle) && mExtraBitmap.getPixel(px, py - 1) == targetColor) {
                            queue.add(new Point(px, py - 1));
                        }
                    }
                }
            }
        }
        invalidate();
    }


    private void FillCircle(Circle circle) {
        int targetColor = mExtraBitmap.getPixel((int) circle.centerX, (int) circle.centerY);
        int fillColor = cDrawColor;

        if (targetColor != fillColor) {
            Queue<Point> queue = new LinkedList<>();
            queue.add(new Point((int) circle.centerX, (int) circle.centerY));

            Set<Point> filledPoints = new HashSet<>();

            while (!queue.isEmpty()) {
                Point point = queue.poll();
                int px = point.x;
                int py = point.y;

                if (px >= 0 && px < mExtraBitmap.getWidth() && py >= 0 && py < mExtraBitmap.getHeight()) {
                    if (isPointInCircle(px, py, circle) && mExtraBitmap.getPixel(px, py) == targetColor && !filledPoints.contains(point)) {
                        mExtraBitmap.setPixel(px, py, fillColor);
                        filledPoints.add(new Point(px, py));

                        if (isPointInCircle(px + 1, py, circle) && mExtraBitmap.getPixel(px + 1, py) == targetColor) {
                            queue.add(new Point(px + 1, py));
                        }
                        if (isPointInCircle(px - 1, py, circle) && mExtraBitmap.getPixel(px - 1, py) == targetColor) {
                            queue.add(new Point(px - 1, py));
                        }
                        if (isPointInCircle(px, py + 1, circle) && mExtraBitmap.getPixel(px, py + 1) == targetColor) {
                            queue.add(new Point(px, py + 1));
                        }
                        if (isPointInCircle(px, py - 1, circle) && mExtraBitmap.getPixel(px, py - 1) == targetColor) {
                            queue.add(new Point(px, py - 1));
                        }
                    }
                }
            }
        }
        invalidate();
    }


    private void undoFloodFillCircle(Circle circle) {
        int targetColor = mExtraBitmap.getPixel((int) circle.centerX, (int) circle.centerY);

        if (targetColor != cDrawColor) {
            Queue<Point> queue = new LinkedList<>();
            queue.add(new Point((int) circle.centerX, (int) circle.centerY));

            Set<Point> filledPoints = new HashSet<>();

            while (!queue.isEmpty()) {
                Point point = queue.poll();
                int px = point.x;
                int py = point.y;

                if (px >= 0 && px < mExtraBitmap.getWidth() && py >= 0 && py < mExtraBitmap.getHeight()) {
                    if (mExtraBitmap.getPixel(px, py) == cDrawColor && !filledPoints.contains(point)) {
                        mExtraBitmap.setPixel(px, py, targetColor);
                        filledPoints.add(new Point(px, py));

                        if (isPointInCircle(px + 1, py, circle)) {
                            queue.add(new Point(px + 1, py));
                        }
                        if (isPointInCircle(px - 1, py, circle)) {
                            queue.add(new Point(px - 1, py));
                        }
                        if (isPointInCircle(px, py + 1, circle)) {
                            queue.add(new Point(px, py + 1));
                        }
                        if (isPointInCircle(px, py - 1, circle)) {
                            queue.add(new Point(px, py - 1));
                        }
                    }
                }
            }
        }
    }


    private void floodFillRec(Rectangle rectangle, float x, float y) {
        int targetColor = mExtraBitmap.getPixel((int) x, (int) y);
        int fillColor = cDrawColor;

        if (targetColor != fillColor) {
            Queue<Point> queue = new LinkedList<>();
            queue.add(new Point((int) x, (int) y));

            while (!queue.isEmpty()) {
                Point point = queue.poll();
                int px = point.x;
                int py = point.y;

                if (px >= 0 && px < mExtraBitmap.getWidth() && py >= 0 && py < mExtraBitmap.getHeight()) {
                    if (mExtraBitmap.getPixel(px, py) == targetColor) {
                        mExtraBitmap.setPixel(px, py, fillColor);

                        if (isPointInRect(px + 1, py, rectangle.getRect()) && mExtraBitmap.getPixel(px + 1, py) == targetColor) {
                            queue.add(new Point(px + 1, py));
                        }
                        if (isPointInRect(px - 1, py, rectangle.getRect()) && mExtraBitmap.getPixel(px - 1, py) == targetColor) {
                            queue.add(new Point(px - 1, py));
                        }
                        if (isPointInRect(px, py + 1, rectangle.getRect()) && mExtraBitmap.getPixel(px, py + 1) == targetColor) {
                            queue.add(new Point(px, py + 1));
                        }
                        if (isPointInRect(px, py - 1, rectangle.getRect()) && mExtraBitmap.getPixel(px, py - 1) == targetColor) {
                            queue.add(new Point(px, py - 1));
                        }
                    }
                }
            }
        }

        invalidate();
    }

    private void scanlineFillPath(MyPath myPath, float x, float y) {
        RectF bounds = new RectF();
        myPath.getPath().computeBounds(bounds, true);

        int targetColor = mExtraBitmap.getPixel((int) x, (int) y);
        int fillColor = cDrawColor;

        if (targetColor != fillColor) {
            for (int py = (int) bounds.top; py <= bounds.bottom; py++) {
                boolean insidePath = false;
                for (int px = (int) bounds.left; px <= bounds.right; px++) {
                    if (isPointInPath(px, py, myPath)) {
                        insidePath = !insidePath;
                    }

                    if (insidePath) {
                        if (mExtraBitmap.getPixel(px, py) == targetColor) {
                            mExtraBitmap.setPixel(px, py, fillColor);
                        }
                    }
                }
            }
        }

        invalidate();
    }




}