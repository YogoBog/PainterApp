package com.example.myapplication;



import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button fill;
    private Button undo;
    private Button blue;
    private Button yellow;
    private Button rec;
    private Button circle;
    private Button path;
    private Button green;
    private Button black;
    public static boolean circActive;
    public static boolean pathActive;
    public static boolean recActive;
    public static boolean fillActive;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fillActive = false;
        recActive = false;
        circActive = false;
        pathActive = true;

        MyCanvasView myCanvasView = findViewById(R.id.myCanvasView);
        findViewById(R.id.resetButton).setOnClickListener(v -> myCanvasView.reset());

        circle = findViewById(R.id.circleButton);
        path = findViewById(R.id.pathButton);
        rec = findViewById(R.id.recButton);
        blue = findViewById(R.id.blueButton);
        yellow = findViewById(R.id.yellowButton);
        green = findViewById(R.id.greenButton);
        black = findViewById(R.id.blackButton);
        undo = findViewById(R.id.undoButton);
        fill = findViewById(R.id.fillButton);


        yellow.setOnClickListener(view -> {
            int newColor = ResourcesCompat.getColor(getResources(), R.color.opaque_yellow, null);
            myCanvasView.setDrawColor(newColor);
            myCanvasView.invalidate();
        });

        blue.setOnClickListener(view -> {
            int newColor = ResourcesCompat.getColor(getResources(), R.color.colorPrimaryDark, null);
            myCanvasView.setDrawColor(newColor);
            myCanvasView.invalidate();
        });

        black.setOnClickListener(view -> {
            int newColor = ResourcesCompat.getColor(getResources(), R.color.black, null);
            myCanvasView.setDrawColor(newColor);
            myCanvasView.invalidate();
        });

        green.setOnClickListener(view -> {
            int newColor = ResourcesCompat.getColor(getResources(), R.color.green, null);
            myCanvasView.setDrawColor(newColor);
            myCanvasView.invalidate();
        });


        circle.setOnClickListener(view -> {
            circActive = true;
            pathActive = false;
            recActive = false;
            fillActive = false;
        });

        path.setOnClickListener(view -> {
            circActive = false;
            recActive = false;
            pathActive = true;
            fillActive = false;
        });

        rec.setOnClickListener(view -> {
            circActive = false;
            recActive = true;
            pathActive = false;
            fillActive = false;

        });

        undo.setOnClickListener(view -> {
            myCanvasView.undo();
            myCanvasView.invalidate();
        });


        fill.setOnClickListener(view -> {
            fillActive = true;
            pathActive = false;
            circActive = false;
            recActive = false;
        });
    }
}